"""
Sentinel
Assessments Application Package
"""