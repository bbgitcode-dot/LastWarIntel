"""
Sentinel
Cockpit Application Package
"""