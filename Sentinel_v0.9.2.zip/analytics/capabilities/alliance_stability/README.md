# Alliance Stability Capability

Provides strategic assessments related to alliance stability.

Contained rules:
- RecruitmentWindowRule
- AllianceCollapseRule
- LeadershipRiskRule (planned)
