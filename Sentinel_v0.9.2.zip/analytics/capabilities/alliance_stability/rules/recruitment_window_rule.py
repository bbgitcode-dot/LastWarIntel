"""Recruitment Window assessment rule."""

class RecruitmentWindowRule:
    """Reference implementation."""

    name = "RecruitmentWindow"

    def evaluate(self, context):
        return None
