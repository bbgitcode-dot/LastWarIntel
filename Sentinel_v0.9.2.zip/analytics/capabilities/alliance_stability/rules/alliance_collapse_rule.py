"""Alliance Collapse assessment rule."""

class AllianceCollapseRule:
    """Reference implementation."""

    name = "AllianceCollapse"

    def evaluate(self, context):
        return None
