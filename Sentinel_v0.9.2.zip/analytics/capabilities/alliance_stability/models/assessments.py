from dataclasses import dataclass

@dataclass(frozen=True)
class RecruitmentWindowAssessment:
    confidence: float
    summary: str

@dataclass(frozen=True)
class AllianceCollapseAssessment:
    confidence: float
    summary: str
