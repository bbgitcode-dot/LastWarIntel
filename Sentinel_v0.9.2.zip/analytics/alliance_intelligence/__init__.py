"""
Sentinel
Alliance Intelligence Package
"""