"""
Sentinel
Recruitability Intelligence Package
"""