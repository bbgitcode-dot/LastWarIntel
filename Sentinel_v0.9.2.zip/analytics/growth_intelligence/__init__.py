"""
Sentinel
Growth Intelligence Package
"""